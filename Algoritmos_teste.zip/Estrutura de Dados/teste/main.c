#include <stdio.h>
#include <stdlib.h>
#define tamanhoVetor 10

int main()
{

    int vetor[tamanhoVetor];
    int i, aux, contador;

    printf("Digite os valores que compoem o vetor:");

    for(i = 0; i < tamanhoVetor; i++){
        scanf("%d", &vetor[i]);
    }

    printf("Array Atual:");

    for(i = 0; i< tamanhoVetor; i++){
        printf("%4d", vetor[i]);
    }

    //Bubblesort
     for (contador = 1; contador < tamanhoVetor; contador++) {
           for (i = 0; i < tamanhoVetor - 1; i++) {
             if (vetor[i] > vetor[i + 1]) {
               aux = vetor[i];
               vetor[i] = vetor[i + 1];
               vetor[i + 1] = aux;
             }
           }
         }

    printf("\n Array em ordem crescente:\n");
    for (i = 0; i < tamanhoVetor; i++) {
     printf("%4d", vetor[i]);
    }
    return 0;

}
