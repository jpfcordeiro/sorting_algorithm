#include <stdio.h>
#include <stdlib.h>
#define tamanhoVetor 10

int main()
{

    int vetor[tamanhoVetor];
    int i, aux, contador = 1;


    printf("Digite os valores que compoem o vetor:");

    for(i = 0; i < tamanhoVetor; i++){
        scanf("%d", &vetor[i]);
    }

    while(contador<tamanhoVetor){
        aux = vetor[contador];
        i = contador - 1;
        while((i >= 0) && (vetor[i]>aux)){
            vetor[i+1] = vetor[i];
            i = i -1;
        }
    vetor[i+1] = aux;
    contador = contador+1;
    }

    printf("\n Array em ordem crescente:\n");
    for (i = 0; i < tamanhoVetor; i++) {
     printf("%4d", vetor[i]);
    }
    return 0;

}
