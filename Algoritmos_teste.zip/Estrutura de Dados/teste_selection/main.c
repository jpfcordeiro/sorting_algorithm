#include <stdio.h>
#include <stdlib.h>
#define tamanhoVetor 10

int main()
{

    int vetor[tamanhoVetor];
    int i, aux, min, contador;


    printf("Digite os valores que compoem o vetor:");

    for(i = 0; i < tamanhoVetor; i++){
        scanf("%d", &vetor[i]);
    }

    for(i = 0; i < (tamanhoVetor-1); i++){
        min = i;
        for(contador = (i+1); contador <tamanhoVetor; contador++){
            if(vetor[contador] < vetor[min]){
                min = contador;
            }
        }
        if(vetor[i] != vetor[min]){
            aux = vetor[i];
            vetor[i] = vetor[min];
            vetor[min] = aux;
        }
    }

    printf("\n Array em ordem crescente:\n");
    for (i = 0; i < tamanhoVetor; i++) {
     printf("%4d", vetor[i]);
    }
    return 0;

}
